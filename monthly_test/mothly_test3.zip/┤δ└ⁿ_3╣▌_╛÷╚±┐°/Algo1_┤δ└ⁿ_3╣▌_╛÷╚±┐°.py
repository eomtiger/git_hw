T = int(input())

for tc in range(1, T+1):
    N = int(input())
    arr = list(map(int, input().split()))       #높이를 배열로 저장
    cnt = 0
    if len(arr) == 1 and arr[0] > 0:          #산이 하나이고 높이가 0보다 클 때
        cnt += 1

    elif len(arr) == 1 and arr[0] == 0:        #산이 하나이고 높이가 0일 때
        pass

    else:
        for i in range(len(arr)):               #산이 여러개이면
            if i == 0 and arr[0] > arr[1]:      #첫째 산은 오른쪽 산보다 높으면
                cnt += 1                        # 1개 추가
            elif i == len(arr)-1 and arr[i] > arr[i-1]:# 마지막 산은 왼쪽 산보다 높으면
                cnt += 1
            elif arr[i] > arr[i-1] and arr[i] >= arr[i+1]: #나머지 산들은 왼쪽 산보다 높고 오른쪽 산보다
                cnt += 1                                   #높거나 같으면 1개 추가
            # print(i, cnt)

    print(f'#{tc} {cnt}')