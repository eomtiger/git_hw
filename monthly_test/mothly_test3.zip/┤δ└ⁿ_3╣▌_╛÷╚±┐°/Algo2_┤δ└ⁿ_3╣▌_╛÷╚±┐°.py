T = int(input())

def pre(v, arr):        #전위 순회 함수
    if v > len(arr):
        return
    a.append(arr[v-1])
    pre(2**v, arr)
    pre(2**v+1, arr)

def ino(v, arr):        #중위 순회 함수
    if v > len(arr):
        return
    ino(2*v, arr)
    b.append(arr[v-1])
    ino(2*v+1, arr)

def post(v, arr):       #후위 순회 함수
    if v > len(arr):
        return
    post(2*v, arr)
    post(2*v+1, arr)
    c.append(arr[v-1])


for tc in range(1, T+1):
    N = int(input())
    arr = []
    for i in range(N):
        arr.append(i+1)
    a = []  #전위 순회 인덱스 담을 리스트
    b = []  #중위 순회
    c = []  #후위 순회

    pre(1, arr)
    ino(1, arr)
    post(1, arr)

    pod = []        #각 정점에서 후보군을 담을 리스트
    for i in range(N):
        pod.append((a[i], b[i], c[i])) # 각 정점 후보군을 튜플로 묶어서 리스트에 담음
    #ex) [(1, 2, 2), (2, 1, 3), (3, 3, 1)]

    rst = []                #결과를 담을 리스트
    for j in range(N):
        rst.append(max(pod[b[j]-1]))    #후보군에서 제일 큰 수를 뽑아서 담음

    #여기부터 rst 출력
    print(f'#{tc}', end = ' ')
    for k in range(len(rst)):
        if k == len(rst) - 1:
            print(rst[k])
        else:
            print(rst[k], end = ' ')





